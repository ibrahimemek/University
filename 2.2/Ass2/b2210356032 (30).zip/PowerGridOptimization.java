import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;

/**
 * This class accomplishes Mission POWER GRID OPTIMIZATION
 */
public class PowerGridOptimization {
    private ArrayList<Integer> amountOfEnergyDemandsArrivingPerHour;



    public PowerGridOptimization(ArrayList<Integer> amountOfEnergyDemandsArrivingPerHour){
        this.amountOfEnergyDemandsArrivingPerHour = amountOfEnergyDemandsArrivingPerHour;
    }

    public ArrayList<Integer> getAmountOfEnergyDemandsArrivingPerHour() {
        return amountOfEnergyDemandsArrivingPerHour;
    }
    /**
     *     Function to implement the given dynamic programming algorithm
     *     SOL(0) <- 0
     *     HOURS(0) <- [ ]
     *     For{j <- 1...N}
     *         SOL(j) <- max_{0<=i<j} [ (SOL(i) + min[ E(j), P(j − i) ] ]
     *         HOURS(j) <- [HOURS(i), j]
     *     EndFor
     *
     * @return OptimalPowerGridSolution
     */
    public OptimalPowerGridSolution getOptimalPowerGridSolutionDP()
    {
        // TODO: YOUR CODE HERE
        int arrLength = amountOfEnergyDemandsArrivingPerHour.size();
        int[] solutions = new int[arrLength + 1];
        ArrayList<Integer>[] allHours = new ArrayList[arrLength + 1];
        solutions[0] = 0;
        allHours[0] = new ArrayList<>();
        for (int j = 1; j < arrLength + 1; j++)
        {
            HashMap<Integer, Integer> allPossibilities = new HashMap<>();
            for (int k = 0; k < j; k++)
            {
                int x = solutions[k] + Math.min(amountOfEnergyDemandsArrivingPerHour.get(j - 1), ((j - k) * (j - k)));
                allPossibilities.put(k, x);
            }
            int max = -1;
            int maxIndex = 0;
            for (int possibility : allPossibilities.keySet())
            {
                if (allPossibilities.get(possibility) > max)
                {
                    max = allPossibilities.get(possibility);
                    maxIndex = possibility;
                }
            }
            allPossibilities.clear();
            solutions[j] = max;
            allHours[j] = new ArrayList<>();
            for (int x : allHours[maxIndex])
                allHours[j].add(x);
            allHours[j].add(j);
            allHours[j].sort(Comparator.naturalOrder());

        }
        OptimalPowerGridSolution op = new OptimalPowerGridSolution(solutions[arrLength], allHours[arrLength]);
        return op;
    }

}
