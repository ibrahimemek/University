import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.Scanner;

/**
 * Main class
 */
// FREE CODE HERE
public class Main {
    public static void main(String[] args) throws IOException {

        /** MISSION POWER GRID OPTIMIZATION BELOW **/

        System.out.println("##MISSION POWER GRID OPTIMIZATION##");
        // TODO: Your code goes here
        // You are expected to read the file given as the first command-line argument to read 
        // the energy demands arriving per hour. Then, use this data to instantiate a 
        // PowerGridOptimization object. You need to call getOptimalPowerGridSolutionDP() method
        // of your PowerGridOptimization object to get the solution, and finally print it to STDOUT.
        File inputFile = new File(args[0]);
        Scanner scanner = new Scanner(inputFile);
        ArrayList<Integer> allDemands = new ArrayList<>();
        int totalDemand = 0;
        while (scanner.hasNextInt())
        {
            int nextInt = scanner.nextInt();
            allDemands.add(nextInt);
            totalDemand += nextInt;
        }

        PowerGridOptimization optimization = new PowerGridOptimization(allDemands);
        OptimalPowerGridSolution opSolution = optimization.getOptimalPowerGridSolutionDP();
        System.out.println("The total number of demanded gigawatts: " + totalDemand);
        System.out.println("Maximum number of satisfied gigawatts: " + opSolution.getmaxNumberOfSatisfiedDemands());
        String hours = "";
        for (int i = 0; i < opSolution.getHoursToDischargeBatteriesForMaxEfficiency().size(); i++)
        {
            if (i == 0) hours += opSolution.getHoursToDischargeBatteriesForMaxEfficiency().get(0);
            else hours += ", " + opSolution.getHoursToDischargeBatteriesForMaxEfficiency().get(i);
        }
        System.out.println("Hours at which the battery bank should be discharged: " + hours);
        System.out.println("The number of unsatisfied gigawatts: " + (totalDemand - opSolution.getmaxNumberOfSatisfiedDemands()));


        System.out.println("##MISSION POWER GRID OPTIMIZATION COMPLETED##");

        /** MISSION ECO-MAINTENANCE BELOW **/

        System.out.println("##MISSION ECO-MAINTENANCE##");
        // TODO: Your code goes here
        // You are expected to read the file given as the second command-line argument to read
        // the number of available ESVs, the capacity of each available ESV, and the energy requirements 
        // of the maintenance tasks. Then, use this data to instantiate an OptimalESVDeploymentGP object.
        // You need to call getMinNumESVsToDeploy(int maxNumberOfAvailableESVs, int maxESVCapacity) method
        // of your OptimalESVDeploymentGP object to get the solution, and finally print it to STDOUT.
        File newFile = new File(args[1]);
        Scanner newScanner = new Scanner(newFile);
        String[] firstLine = newScanner.nextLine().split(" ");
        int maxESV = Integer.parseInt(firstLine[0]);
        int maxESVCapacity = Integer.parseInt(firstLine[1]);
        String[] secondLine = newScanner.nextLine().split(" ");
        ArrayList<Integer> allValues = new ArrayList<>();
        for (String st: secondLine)
            allValues.add(Integer.parseInt(st));


        OptimalESVDeploymentGP esv = new OptimalESVDeploymentGP(allValues);
        int maxNumber = esv.getMinNumESVsToDeploy(maxESV, maxESVCapacity);
        if (maxNumber == -1)
        {
            System.out.println("Warning: Mission Eco-Maintenance Failed.");
            System.out.println("##MISSION ECO-MAINTENANCE COMPLETED##");
            return;
        }
        System.out.println("The minimum number of ESVs to deploy: " + maxNumber);
        for (int i = 0; i < maxNumber; i++)
        {
            System.out.println("ESV " + (i + 1) + " tasks: " + esv.getMaintenanceTasksAssignedToESVs().get(i));
        }
        System.out.println("##MISSION ECO-MAINTENANCE COMPLETED##");
    }
}
