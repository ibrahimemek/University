import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.*;

class UrbanTransportationApp implements Serializable {
    static final long serialVersionUID = 99L;
    double totalTime;

    public HyperloopTrainNetwork readHyperloopTrainNetwork(String filename) {
        HyperloopTrainNetwork hyperloopTrainNetwork = new HyperloopTrainNetwork();
        hyperloopTrainNetwork.readInput(filename);
        return hyperloopTrainNetwork;
    }

    /**
     * Function calculate the fastest route from the user's desired starting point to 
     * the desired destination point, taking into consideration the hyperloop train
     * network. 
     * @return List of RouteDirection instances
     */
    public List<RouteDirection> getFastestRouteDirections(HyperloopTrainNetwork network) {
        for (TrainLine line : network.lines)
        {
            for (Station station : line.trainLineStations)
            {
                station.line = line.trainLineName;
                station.neighborStations = new ArrayList<>();
                station.tookTime = Double.MAX_VALUE;
            }
        }
        List<RouteDirection> routeDirections = new ArrayList<>();
        ArrayList<Station> allStations = new ArrayList<>();
        allStations.add(network.startPoint);
        network.startPoint.neighborStations = new ArrayList<>();
        network.startPoint.tookTime = 0.0;
        network.destinationPoint.neighborStations = new ArrayList<>();
        network.destinationPoint.tookTime = Double.MAX_VALUE;


        for(TrainLine line : network.lines)
        {
            Station prevStat = null;
            for (Station station : line.trainLineStations)
            {
                if (prevStat != null)
                {

                    prevStat.neighborStations.add(station);
                    station.neighborStations.add(prevStat);
                }

                prevStat = station;
                allStations.add(station);
            }
        }
        allStations.add(network.destinationPoint);
        for (int i = 0; i < allStations.size(); i++)
        {
            for (int j = 0; j < allStations.size(); j++)
            {
                if (i == j) continue;
                if (allStations.get(i).line == null || allStations.get(j).line == null || (!allStations.get(i).line.equals(allStations.get(j).line)))
                {
                    allStations.get(i).neighborStations.add(allStations.get(j));
                }
            }
        }
        Station currentStation = network.startPoint;
        currentStation.tookTime = 0.0;
        PriorityQueue<Station> unvisitedStations = new PriorityQueue<>(Comparator.comparingDouble(Station::getTime));
        unvisitedStations.offer(currentStation);
        ArrayList<Station> visitedStations = new ArrayList<>();
        while (true)
        {
            if (unvisitedStations.contains(currentStation))
                unvisitedStations.remove(currentStation);
            visitedStations.add(currentStation);
            for (Station neighbor : currentStation.neighborStations)
            {
                if (visitedStations.contains(neighbor)) continue;
                boolean trainRide = neighbor.line != null && currentStation.line != null && neighbor.line.equals(currentStation.line);
                double speed = trainRide ? network.averageTrainSpeed : network.averageWalkingSpeed;

                if (currentStation.tookTime + currentStation.calculateTime(neighbor, speed) < neighbor.tookTime)
                {
                    neighbor.tookTime = currentStation.tookTime + currentStation.calculateTime(neighbor, speed);
                    neighbor.parent = currentStation;
                    unvisitedStations.remove(neighbor);
                    unvisitedStations.offer(neighbor);

                }
            }
            if (unvisitedStations.isEmpty()) break;

            currentStation = unvisitedStations.poll();
            while (visitedStations.contains(currentStation))
            {
                unvisitedStations.remove(currentStation);
                currentStation = unvisitedStations.poll();

            }
        }
        Station currentStat = network.destinationPoint;
        double total = 0.0;
        while (!currentStat.equals(network.startPoint) && currentStat.parent != null)
        {
            boolean trainRide = currentStat.parent.line != null && currentStat.line != null && currentStat.parent.line.equals(currentStat.line);
            double speed = trainRide ? network.averageTrainSpeed : network.averageWalkingSpeed;
            double duration = currentStat.calculateTime(currentStat.parent, speed);
            RouteDirection routeDirection = new RouteDirection(currentStat.parent.description, currentStat.description,
                    duration, trainRide);
            routeDirections.add(routeDirection);
            currentStat = currentStat.parent;
            total += duration;
        }
        totalTime = total;
        Collections.reverse(routeDirections);

        // TODO: Your code goes here

        return routeDirections;
    }

    /**
     * Function to print the route directions to STDOUT
     */
    public void printRouteDirections(List<RouteDirection> directions) {

        // TODO: Your code goes here

        int step = 1;
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(2);
        df.setMinimumFractionDigits(2);
        System.out.println("The fastest route takes " + ((int)Math.round(totalTime))  + " minute(s).");
        System.out.println("Directions\n" + "----------");
        for (RouteDirection direction : directions)
        {
            String output;
            if (direction.trainRide)
                output = "Get on the train ";
            else
                output = "Walk ";
            System.out.println(step + ". " + output +  "from " + '"' + direction.startStationName + '"' + " to " + '"' + direction.endStationName + '"' + " for " + df.format( direction.duration) + " minutes.");
            step++;
        }

    }
}