import java.io.Serializable;
import java.util.ArrayList;

public class Station implements Serializable {
    static final long serialVersionUID = 55L;
    String line = null;

    public Point coordinates;
    public String description;
    public ArrayList<Station> neighborStations;
    public Double tookTime;
    public Double getTime(){return tookTime;}
    public Station parent = null;
    public double calculateTime(Station otherStation, double speed)
    {
        int x = coordinates.x - otherStation.coordinates.x;
        int y = coordinates.y - otherStation.coordinates.y;
        if (x < 0)  x*= -1;
        if (y < 0) y *= -1;

        return Math.sqrt((x * x) + (y * y)) / speed;

    }

    public Station(Point coordinates, String description) {
        this.coordinates = coordinates;
        this.description = description;
    }

    public String toString() {
        return this.description;
    }
}
