import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MissionGenesis {

    // Private fields
    private MolecularData molecularDataHuman; // Molecular data for humans
    private MolecularData molecularDataVitales; // Molecular data for Vitales

    // Getter for human molecular data
    public MolecularData getMolecularDataHuman() {
        return molecularDataHuman;
    }

    // Getter for Vitales molecular data
    public MolecularData getMolecularDataVitales() {
        return molecularDataVitales;
    }

    // Method to read XML data from the specified filename
    // This method should populate molecularDataHuman and molecularDataVitales fields once called
    public void readXML(String filename) {
        try {
            // Create a DocumentBuilderFactory
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            File file = new File(filename);
            Document document = builder.parse(file);
            document.getDocumentElement().normalize();
            Element doc = document.getDocumentElement();
            NodeList humanNodes = doc.getElementsByTagName("HumanMolecularData").item(0).getChildNodes();
            List<Molecule> humanMolecules = findMolecules(humanNodes);
            molecularDataHuman = new MolecularData(humanMolecules);

            NodeList vitalesNodes = doc.getElementsByTagName("VitalesMolecularData").item(0).getChildNodes();
            List<Molecule> vitalesMolecules = findMolecules(vitalesNodes);
            molecularDataVitales = new MolecularData(vitalesMolecules);

        } catch (Exception e) {}
    }

    // Helper method to parse molecules from NodeList
    private List<Molecule> findMolecules(NodeList nodeList) {
        List<Molecule> molecules = new ArrayList<>();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                String id = element.getElementsByTagName("ID").item(0).getTextContent();
                int bondStrength = Integer.parseInt(element.getElementsByTagName("BondStrength").item(0).getTextContent());
                List<String> bonds = new ArrayList<>();
                NodeList bondList = element.getElementsByTagName("Bonds").item(0).getChildNodes();
                for (int j = 0; j < bondList.getLength(); j++) {
                    Node bondNode = bondList.item(j);
                    if (bondNode.getNodeType() == Node.ELEMENT_NODE) {
                        bonds.add(bondNode.getTextContent());
                    }
                }
                molecules.add(new Molecule(id, bondStrength, bonds));
            }
        }
        return molecules;
    }
}


/*
File file = new File(filename);
        DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder documentBuilder = builderFactory.newDocumentBuilder();
            Document document = documentBuilder.parse(file);
            document.getDocumentElement().normalize();
            NodeList nodeList = document.getElementsByTagName("HumanMolecularData");
            NodeList moleculeElement = nodeList.item(0).getChildNodes();

            System.out.println(nodeList.getLength());
            for (int i = 0; i < moleculeElement.getLength(); i++)
            {
                Node xx = moleculeElement.item(i);
                Node id = xx.getFirstChild();
                System.out.println(id.getNodeValue());
            }
        } catch (ParserConfigurationException | SAXException | IOException e) {
            throw new RuntimeException(e);
        }

 */
