import java.util.*;

// Class representing molecular data
public class MolecularData {

    // Private fields
    private final List<Molecule> molecules; // List of molecules

    // Constructor
    public MolecularData(List<Molecule> molecules) {
        this.molecules = molecules;
    }

    // Getter for molecules
    public List<Molecule> getMolecules() {
        return molecules;
    }

    // Method to identify molecular structures
    // Return the list of different molecular structures identified from the input data
    public List<MolecularStructure> identifyMolecularStructures() {

        ArrayList<MolecularStructure> structures = new ArrayList<>();
        MolecularStructure structure = new MolecularStructure();
        ArrayList<String> currentBondList = new ArrayList<>();
        for (Molecule mol : molecules)
        {


            if(!currentBondList.contains(mol.getId()) && currentBondList.size() != 0)
            {
                boolean bIsFound = false;
                for (String s : mol.getBonds())
                {
                    if (currentBondList.contains(s))
                    {
                        bIsFound = true;
                        break;
                    }
                }
                if (!bIsFound)
                {
                    currentBondList.clear();
                    structures.add(structure);
                    structure = new MolecularStructure();
                }

            }

            structure.addMolecule(mol);
            currentBondList.addAll(mol.getBonds());

        }

        structures.add(structure);

        /* YOUR CODE HERE */

        return structures;
    }

    // Method to print given molecular structures
    public void printMolecularStructures(List<MolecularStructure> molecularStructures, String species) {

        /* YOUR CODE HERE */
        System.out.print(molecularStructures.size() + " molecular structures have been discovered in ");
        if (species.equals("typical humans")) System.out.println("typical humans.");
        else System.out.println("Vitales individuals.");
        String currentList = "[";
        int atStruct = 1;
        for (MolecularStructure eachStruct : molecularStructures)
        {
            System.out.print("Molecules in Molecular Structure " + atStruct + ": ");
            boolean bIsFirst = true;
            eachStruct.getMolecules().sort(Comparator.naturalOrder());
            for (Molecule mol : eachStruct.getMolecules())
            {
                if (!bIsFirst) currentList += ", ";
                currentList += mol.getId();
                bIsFirst = false;

            }
            currentList += "]";
            System.out.println(currentList);
            currentList = "[";
            atStruct++;

        }


    }


    // Method to identify anomalies given a source and target molecular structure
    // Returns a list of molecular structures unique to the targetStructure only
    public static ArrayList<MolecularStructure> getVitalesAnomaly(List<MolecularStructure> sourceStructures, List<MolecularStructure> targetStructures) {
        ArrayList<MolecularStructure> anomalyList = new ArrayList<>();
        for (MolecularStructure ms : targetStructures)
        {
            if (!sourceStructures.contains(ms))
                anomalyList.add(ms);
        }

        /* YOUR CODE HERE */

        return anomalyList;
    }

    // Method to print Vitales anomalies
    public void printVitalesAnomaly(List<MolecularStructure> molecularStructures) {

        /* YOUR CODE HERE */
        String currentList = "[";
        System.out.println("Molecular structures unique to Vitales individuals:" );

        for (MolecularStructure eachStruct : molecularStructures)
        {
            boolean bIsFirst = true;
            eachStruct.getMolecules().sort(Comparator.naturalOrder());
            for (Molecule mol : eachStruct.getMolecules())
            {
                if (!bIsFirst) currentList += ", ";
                currentList += mol.getId();
                bIsFirst = false;

            }
            currentList += "]";
            System.out.println(currentList);
            currentList = "[";

        }

    }
}
