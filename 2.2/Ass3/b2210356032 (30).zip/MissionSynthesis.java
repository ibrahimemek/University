import java.util.*;


// Class representing the Mission Synthesis
public class MissionSynthesis {

    // Private fields
    private final List<MolecularStructure> humanStructures; // Molecular structures for humans
    private final ArrayList<MolecularStructure> diffStructures; // Anomalies in Vitales structures compared to humans

    private ArrayList<Molecule> minimumMolecules;

    // Constructor
    public MissionSynthesis(List<MolecularStructure> humanStructures, ArrayList<MolecularStructure> diffStructures) {
        this.humanStructures = humanStructures;
        this.diffStructures = diffStructures;
    }

    // Method to synthesize bonds for the serum
    public List<Bond> synthesizeSerum() {
        List<Bond> serum = new ArrayList<>();
        minimumMolecules = findMinimumStrength();
        HashMap<Molecule[], Double> bondStrengths = new HashMap<>();
        Molecule[] minPair = {null, null};

        for (int i = 0; i < minimumMolecules.size(); i++)
        {
            for (int j = i + 1; j < minimumMolecules.size(); j++)
            {
                Double sum = (minimumMolecules.get(i).getBondStrength() + minimumMolecules.get(j).getBondStrength()) / 2.0;
                Molecule[] pair ={minimumMolecules.get(i), minimumMolecules.get(j)};
                bondStrengths.put(pair, sum);

            }
        }
        ArrayList<Molecule > edgeList = new ArrayList<>();
        ArrayList<ArrayList<Molecule>> disconnected = new ArrayList<>();
        ArrayList<Molecule> disconnectedElements = new ArrayList<>();
        while (true)
        {
            if (bondStrengths.size() == 0) break;
            double minValue = Double.MAX_VALUE;
            for (Molecule[] moleculePair : bondStrengths.keySet())
            {
                if (bondStrengths.get(moleculePair) <= minValue)
                {
                    minValue = bondStrengths.get(moleculePair);
                    minPair = moleculePair;
                }
            }
            if (edgeList.size() == 0)
            {
                Bond bond = new Bond(minPair[0], minPair[1], minValue);
                if (!edgeList.contains(minPair[0]))
                    edgeList.add(minPair[0]);
                if (!edgeList.contains(minPair[1]))
                    edgeList.add(minPair[1]);
                bondStrengths.remove(minPair);
                serum.add(bond);
            }
            else if (edgeList.contains(minPair[0]) && edgeList.contains(minPair[1]))
                bondStrengths.remove(minPair);
            else if (edgeList.contains(minPair[0]) || edgeList.contains(minPair[1]))
            {
                if (disconnectedElements.contains(minPair[0]) || disconnectedElements.contains(minPair[1]))
                {
                    int index = 0;
                    for (ArrayList<Molecule> array: disconnected)
                    {
                        if (array.contains(minPair[0]) || array.contains(minPair[1]))
                        {
                            for (Molecule mol : array)
                            {
                                edgeList.add(mol);
                                disconnectedElements.remove(mol);
                            }
                            break;

                        }
                        index++;
                    }
                    disconnected.remove(index);
                }

                Bond bond = new Bond(minPair[0], minPair[1], minValue);
                if (!edgeList.contains(minPair[0]))
                    edgeList.add(minPair[0]);
                if (!edgeList.contains(minPair[1]))
                    edgeList.add(minPair[1]);
                bondStrengths.remove(minPair);
                serum.add(bond);
            }
            else if (disconnectedElements.contains(minPair[0]) && disconnectedElements.contains(minPair[1]))
            {
                bondStrengths.remove(minPair);
            }
            else if (disconnectedElements.contains(minPair[0]) || disconnectedElements.contains(minPair[1]))
            {
                for (ArrayList<Molecule> array: disconnected)
                {
                    if (array.contains(minPair[0]) || array.contains(minPair[1]))
                    {
                        if (array.contains(minPair[0]))
                        {
                            array.add(minPair[1]);
                            disconnectedElements.add(minPair[1]);
                        }
                        else if (array.contains(minPair[1]))
                        {
                            array.add(minPair[0]);
                            disconnectedElements.add(minPair[0]);

                        }
                        Bond bond = new Bond(minPair[0], minPair[1], minValue);
                        bondStrengths.remove(minPair);
                        serum.add(bond);
                    }
                }
            }
            else
            {
                Bond bond = new Bond(minPair[0], minPair[1], minValue);
                disconnectedElements.add(minPair[0]);
                disconnectedElements.add(minPair[1]);
                ArrayList<Molecule> mols = new ArrayList<>();
                mols.add(minPair[0]);
                mols.add(minPair[1]);
                disconnected.add(mols);
                bondStrengths.remove(minPair);
                serum.add(bond);
            }



        }
        /*
        while (true)
        {

            if (bondStrengths.size() == 0) break;
            double minValue = Double.MAX_VALUE;
            for (Molecule[] moleculePair : bondStrengths.keySet())
            {
                if (bondStrengths.get(moleculePair) <= minValue)
                {
                    minValue = bondStrengths.get(moleculePair);
                    minPair = moleculePair;
                }
            }


            if ((edgeList.contains(minPair[0]) && edgeList.contains(minPair[1])))
                bondStrengths.remove(minPair);
            else
            {
                Bond bond = new Bond(minPair[0], minPair[1], minValue);
                for (Molecule mol : minPair[0].connectedList)
                {
                    if (mol != minPair[0])
                        mol.connectedList.add(minPair[1]);
                }
                minPair[0].connectedList.add(minPair[1]);
                for (Molecule mol : minPair[1].connectedList)
                {
                    if (mol != minPair[1])
                        mol.connectedList.add(minPair[0]);
                }
                minPair[1].connectedList.add(minPair[0]);
                if (!edgeList.contains(minPair[0]))
                    edgeList.add(minPair[0]);
                if (!edgeList.contains(minPair[1]))
                    edgeList.add(minPair[1]);
                bondStrengths.remove(minPair);
                serum.add(bond);

            }

        }
         */


        /* YOUR CODE HERE */

        return serum;
    }


    Molecule findMol(String molName)
    {
        for (Molecule mol : minimumMolecules)
        {
            if (mol.getId().equals(molName))
                return mol;
        }
        return null;
    }
    private ArrayList<Molecule> findMinimumStrength()
    {
        ArrayList<Molecule> minimums = new ArrayList<>();
        System.out.print("Typical human molecules selected for synthesis: ");
        findMinimum(minimums, humanStructures);
        System.out.print("Vitales molecules selected for synthesis: ");
        findMinimum(minimums, diffStructures);

        return  minimums;
    }

    private void findMinimum(ArrayList<Molecule> minimums, List<MolecularStructure> diffStructures) {
        String output = "[";
        for (MolecularStructure ms : diffStructures)
        {
            Collections.sort(ms.getMolecules(), new Comparator<Molecule>() {
                @Override
                public int compare(Molecule o1, Molecule o2) {
                    if (o1.getBondStrength() > o2.getBondStrength())
                        return 1;
                    if (o1.getBondStrength() < o2.getBondStrength())
                        return -1;
                    return 0;
                }
            });
            if (!output.equals("["))
                output += ", " + ms.getMolecules().get(0);
            else
                output += ms.getMolecules().get(0);
            minimums.add(ms.getMolecules().get(0));
        }
        System.out.println(output + "]");
    }

    // Method to print the synthesized bonds
    public void printSynthesis(List<Bond> serum)
    {
        /* YOUR CODE HERE */
        System.out.println("Synthesizing the serum...");
        double sum = 0.0;

        for (Bond bond : serum)
        {
            if (bond.getFrom().compareTo(bond.getTo()) > 0)
                System.out.println("Forming a bond between " + bond.getTo() + " - " + bond.getFrom() + " with strength " + bond.getWeight() + "0");
            else
                System.out.println("Forming a bond between " + bond.getFrom() + " - " + bond.getTo() + " with strength " + bond.getWeight() + "0");
            sum += bond.getWeight();

        }
        System.out.println("The total serum bond strength is " + sum + "0");

    }
}
/*
minimumMolecules = findMinimumStrength();
        HashMap<Molecule[], Double> bondStrengths = new HashMap<>();
        Double minimumValue = Double.MAX_VALUE;
        Molecule[] minPair = {null, null};

        for (int i = 0; i < minimumMolecules.size(); i++)
        {
            for (int j = i + 1; j < minimumMolecules.size(); j++)
            {
                Double sum = (minimumMolecules.get(i).getBondStrength() + minimumMolecules.get(j).getBondStrength()) / 2.0;
                Molecule[] pair ={minimumMolecules.get(i), minimumMolecules.get(j)};
                bondStrengths.put(pair, sum);

            }
        }
        ArrayList<String > edgeList = new ArrayList<>();
        while (true)
        {
            if (bondStrengths.size() == 0) break;
            double minValue = Double.MAX_VALUE;
            for (Molecule[] moleculePair : bondStrengths.keySet())
            {
                if (bondStrengths.get(moleculePair) < minValue)
                {
                    minValue = bondStrengths.get(moleculePair);
                    minPair = moleculePair;
                }
            }
            if (edgeList.contains(minPair[0].getId()) && edgeList.contains(minPair[1].getId()))
                bondStrengths.remove(minPair);
            else
            {
                Bond bond;
                if (minPair[0].compareTo(minPair[1]) > 0)
                {
                    bond = new Bond(minPair[0], minPair[1], minValue);

                }
                else
                {
                    bond = new Bond(minPair[1], minPair[0], minValue);
                }
                System.out.println(minPair[0] + " " + minPair[1] + " " + minValue);
                serum.add(bond);
                edgeList.add(minPair[0].getId());
                edgeList.add(minPair[1].getId());
            }

        }
 */
/*
minimumMolecules = findMinimumStrength();
        ArrayList<Molecule> currentPath = new ArrayList<>();


        for (Molecule root : minimumMolecules) {
            boolean bShouldContinue = false;
            for (Molecule currentMolecule : minimumMolecules)
            {
                if (currentMolecule.bIsVisited || currentMolecule.equals(root)) continue;
                bShouldContinue = true;
                Double calculation = (currentMolecule.getBondStrength() + root.getBondStrength()) / 2.0;
                System.out.println("root " + root.getId() + " cal:" + calculation + "  currentMolecule  " + currentMolecule.getId() + "  " + currentMolecule.bondDistance);
                if (calculation < currentMolecule.bondDistance)
                {
                    root.bondMolecule = currentMolecule;

                }
            }

            if (!bShouldContinue)
                break;

            root.bondMolecule.bondDistance = (root.bondMolecule.getBondStrength() + root.getBondStrength()) / 2.0;
            Bond bond = new Bond(root, root.bondMolecule, root.bondMolecule.bondDistance);
            //System.out.println(" " + root + " " + root.bondMolecule + " " + root.bondMolecule.bondDistance);
            serum.add(bond);
            root.bIsVisited = true;
        }

 */
