#define _CRT_SECURE_NO_WARNINGS
#include "Network.h"
#include <fstream>
#include <sstream>
#include <chrono>
#include <iomanip>

Network::Network() {

}

void Network::process_commands(vector<Client>& clients, vector<string>& commands, int message_limit,
    const string& sender_port, const string& receiver_port)
{
    AllClientsVector = clients;
    // TODO: Execute the commands given as a vector of strings while utilizing the remaining arguments.
    /* Don't use any static variables, assume this method will be called over and over during testing.
     Don't forget to update the necessary member variables after processing each command. For example,
     after the MESSAGE command, the outgoing queue of the sender must have the expected frames ready to send. */
    for (auto& EachCommand : commands)
    {
        stringstream ss(EachCommand);
        string CurrentCommand;
        ss >> CurrentCommand;
        if (CurrentCommand == "MESSAGE")
        {
            string SenderId;
            string ReceiverId;
            ss >> SenderId >> ReceiverId;
            Client* Sender;
            Client* Receiver;
            Sender = FindClientById(clients, SenderId);
            Receiver = FindClientById(clients, ReceiverId);

            bool bShouldAdd = false;
            string Message;
            for (auto& EachChar : EachCommand)
            {
                if (EachChar == '#' && bShouldAdd) break;
                if (bShouldAdd) Message += EachChar;
                if (EachChar == '#' && !bShouldAdd) bShouldAdd = true;
            }
            cout << "--------------------------------------------------------------------------------------" << endl;
            cout << "Command: " << EachCommand << endl;
            cout << "--------------------------------------------------------------------------------------" << endl;
            cout << "Message to be sent: " << '"' << Message << '"' << endl << endl;
            for (size_t i = 0; i < Message.size() / message_limit + 1; i++)
            {
                string FrameMessage;
                Client* NextCli = FindClientById(clients, Sender->routing_table[ReceiverId]);
                if (!NextCli) continue;
                
                if (i == Message.size() / message_limit)
                {
                    if (Message.size() % message_limit == 0) continue;
                    FrameMessage = Message.substr(i * message_limit, Message.size() - (i * message_limit));
                }
                else FrameMessage = Message.substr(i * message_limit, message_limit);
                string NextHopMac = NextCli->client_mac;
                Packet* PhysicalPacket = new PhysicalLayerPacket(3, Sender->client_mac, NextHopMac);
                if (Message.size() % message_limit == 0) PhysicalPacket->MaxFrameNumber = Message.size() / message_limit;
                else PhysicalPacket->MaxFrameNumber = Message.size() / message_limit + 1;
                stack<Packet*> CurrentStack;
                Packet* ApplicationPacket = new ApplicationLayerPacket(0, SenderId, ReceiverId, FrameMessage);
                Packet* TransportPacket = new TransportLayerPacket(1, sender_port, receiver_port);
                Packet* NetworkPacket = new NetworkLayerPacket(2, Sender->client_ip, Receiver->client_ip);


                PhysicalPacket->FinalDestination = ReceiverId;
                PhysicalPacket->FrameNumber = i + 1;

                PhysicalPacket->CurrentMessage = FrameMessage;
                PhysicalPacket->FirstSenderId = SenderId;
                CurrentStack.push(ApplicationPacket);
                CurrentStack.push(TransportPacket);
                CurrentStack.push(NetworkPacket);
                CurrentStack.push(PhysicalPacket);
                Sender->outgoing_queue.push(CurrentStack);
                cout << "Frame #" << i + 1 << endl;
                cout << "Sender MAC address: " << Sender->client_mac << ", " << "Receiver MAC address: " << NextHopMac << endl;
                cout << "Sender IP address: " << Sender->client_ip << ", " << "Receiver IP address: " << Receiver->client_ip << endl;
                cout << "Sender port number: " << sender_port << ", " << "Receiver port number: " << receiver_port << endl;
                cout << "Sender ID: " << Sender->client_id << ", " << "Receiver ID: " << Receiver->client_id << endl;
                cout << "Message chunk carried: " << '"' << FrameMessage << '"' << endl;
                cout << "Number of hops so far: " << PhysicalPacket->HopCount << endl;
                cout << "--------" << endl;

            }
        }
        else if (CurrentCommand == "SEND")
        {
            cout << "-------------" << endl << "Command: SEND" << endl << "-------------" << endl;

            for (auto& EachClient : clients)
            {
                if (EachClient.outgoing_queue.size() == 0) continue;
                PhysicalLayerPacket* NextHopMac = dynamic_cast<PhysicalLayerPacket*>(EachClient.outgoing_queue.front().top());
                if (!NextHopMac) continue;
                string AllMessage = "";
                string Message = "";
                while (EachClient.outgoing_queue.size() != 0)
                {

                    NextHopMac = dynamic_cast<PhysicalLayerPacket*>(EachClient.outgoing_queue.front().top());
                    Client* NextClient = FindClientByMac(clients, NextHopMac->receiver_MAC_address);

                    if (!NextClient)
                    {

                        Message += NextHopMac->CurrentMessage;

                        if (NextHopMac->FrameNumber == NextHopMac->MaxFrameNumber)
                        {
                            // todo delete previous log

                            auto now = std::chrono::system_clock::now();
                            std::time_t now_c = std::chrono::system_clock::to_time_t(now);
                            std::tm tm_now = *std::localtime(&now_c);
                            std::stringstream ss;
                            ss << std::put_time(&tm_now, "%Y-%m-%d %H:%M:%S");
                            std::string str_time = ss.str();
                            EachClient.log_entries.push_back(Log(str_time, Message, NextHopMac->MaxFrameNumber, NextHopMac->HopCount,
                                NextHopMac->FirstSenderId, NextHopMac->FinalDestination, false, ActivityType::MESSAGE_DROPPED));
                            Message = "";
                        }
                        auto temp = EachClient.outgoing_queue.front();
                        EachClient.outgoing_queue.pop();
                        while (temp.size() != 0)
                        {
                            auto temp2 = temp.top();
                            temp.pop();
                            delete temp2;
                        }
                        continue;
                    }

                    Client* SenderClient = FindClientById(clients, NextHopMac->FirstSenderId);
                    NextHopMac->HopCount++;
                    cout << "Client " << EachClient.client_id << " sending frame #" << NextHopMac->FrameNumber << " to client " << NextClient->client_id << endl;
                    cout << "Sender MAC address: " << EachClient.client_mac << ", " << "Receiver MAC address: " << NextHopMac->receiver_MAC_address << endl;
                    cout << "Sender IP address: " << SenderClient->client_ip << ", " << "Receiver IP address: " << FindClientById(clients, NextHopMac->FinalDestination)->client_ip << endl;
                    cout << "Sender port number: " << sender_port << ", " << "Receiver port number: " << receiver_port << endl;
                    cout << "Sender ID: " << SenderClient->client_id << ", " << "Receiver ID: " << NextHopMac->FinalDestination << endl;
                    cout << "Message chunk carried: " << '"' << NextHopMac->CurrentMessage << '"' << endl;
                    cout << "Number of hops so far: " << NextHopMac->HopCount << endl;
                    cout << "--------" << endl;

                    AllMessage += NextHopMac->CurrentMessage;
                    if (NextHopMac->MaxFrameNumber == NextHopMac->FrameNumber && NextHopMac->FirstSenderId == EachClient.client_id)
                    {

                        auto now = std::chrono::system_clock::now();
                        std::time_t now_c = std::chrono::system_clock::to_time_t(now);
                        std::tm tm_now = *std::localtime(&now_c);
                        std::stringstream ss;
                        ss << std::put_time(&tm_now, "%Y-%m-%d %H:%M:%S");
                        std::string str_time = ss.str();
                        EachClient.log_entries.push_back(Log(str_time, AllMessage, NextHopMac->MaxFrameNumber, NextHopMac->HopCount,
                            NextHopMac->FirstSenderId, NextHopMac->FinalDestination, true, ActivityType::MESSAGE_SENT));
                        AllMessage = "";
                    }
                    NextClient->incoming_queue.push(EachClient.outgoing_queue.front());
                    EachClient.outgoing_queue.pop();
                }

            }
        }
        else if (CurrentCommand == "RECEIVE")
        {
            cout << "----------------" << endl << "Command: RECEIVE" << endl << "----------------" << endl;
            for (auto& EachClient : clients)
            {
                if (EachClient.incoming_queue.size() == 0) continue;
                string Message = "";
                while (EachClient.incoming_queue.size() != 0)
                {
                    PhysicalLayerPacket* NextHopMac = dynamic_cast<PhysicalLayerPacket*>(EachClient.incoming_queue.front().top());
                    if (!NextHopMac)
                    {
                        EachClient.incoming_queue.pop();
                        continue;
                    }
                    if (NextHopMac->FinalDestination == EachClient.client_id)
                    {
                        Message += NextHopMac->CurrentMessage;
                        // reached the final destination
                        Client* Sender = FindClientById(clients, NextHopMac->FirstSenderId);
                        cout << "Client " << EachClient.client_id << " receiving frame #" << NextHopMac->FrameNumber << " from client " << FindClientByMac(clients, NextHopMac->sender_MAC_address)->client_id << ", originating from client " << NextHopMac->FirstSenderId << endl;
                        cout << "Sender MAC address: " << NextHopMac->sender_MAC_address << ", " << "Receiver MAC address: " << NextHopMac->receiver_MAC_address << endl;
                        cout << "Sender IP address: " << Sender->client_ip << ", " << "Receiver IP address: " << FindClientById(clients, NextHopMac->FinalDestination)->client_ip << endl;
                        cout << "Sender port number: " << sender_port << ", " << "Receiver port number: " << receiver_port << endl;
                        cout << "Sender ID: " << Sender->client_id << ", " << "Receiver ID: " << NextHopMac->FinalDestination << endl;
                        cout << "Message chunk carried: " << '"' << NextHopMac->CurrentMessage << '"' << endl;
                        cout << "Number of hops so far: " << NextHopMac->HopCount << endl;
                        cout << "--------" << endl;
                        if (NextHopMac->FrameNumber == NextHopMac->MaxFrameNumber)
                        {
                            // todo delete previous log

                            cout << "Client " << EachClient.client_id << " received the message " << '"' << Message << '"' << " from client " << NextHopMac->FirstSenderId << "." << endl;
                            cout << "--------" << endl;
                            auto now = std::chrono::system_clock::now();
                            std::time_t now_c = std::chrono::system_clock::to_time_t(now);
                            std::tm tm_now = *std::localtime(&now_c);
                            std::stringstream ss;
                            ss << std::put_time(&tm_now, "%Y-%m-%d %H:%M:%S");
                            std::string str_time = ss.str();
                            EachClient.log_entries.push_back(Log(str_time, Message, NextHopMac->MaxFrameNumber, NextHopMac->HopCount,
                                NextHopMac->FirstSenderId, NextHopMac->FinalDestination, true, ActivityType::MESSAGE_RECEIVED));
                            Message = "";
                        }
                        auto temp = EachClient.incoming_queue.front();
                        EachClient.incoming_queue.pop();
                        while (temp.size() != 0)
                        {
                            auto temp2 = temp.top();
                            temp.pop();
                            delete temp2;
                        }
                        continue; // in order to don't run the rest of the code
                    }

                    if ((EachClient.routing_table[NextHopMac->FinalDestination] == "") || (!FindClientById(clients, EachClient.routing_table[NextHopMac->FinalDestination])))
                    {
                        Message += NextHopMac->CurrentMessage;
                        cout << "Client " << EachClient.client_id << " receiving frame #" << NextHopMac->FrameNumber << " from client " << FindClientByMac(clients, NextHopMac->sender_MAC_address)->client_id << ", but intended for client " << NextHopMac->FinalDestination << ". Forwarding..." << endl;
                        cout << "Error: Unreachable destination. Packets are dropped after " << NextHopMac->HopCount << " hops!" << endl;
                        if (NextHopMac->MaxFrameNumber == NextHopMac->FrameNumber)
                            cout << "--------" << endl;
                        if (NextHopMac->FrameNumber == NextHopMac->MaxFrameNumber)
                        {
                            // todo delete previous log

                            auto now = std::chrono::system_clock::now();
                            std::time_t now_c = std::chrono::system_clock::to_time_t(now);
                            std::tm tm_now = *std::localtime(&now_c);
                            std::stringstream ss;
                            ss << std::put_time(&tm_now, "%Y-%m-%d %H:%M:%S");
                            std::string str_time = ss.str();
                            EachClient.log_entries.push_back(Log(str_time, Message, NextHopMac->MaxFrameNumber, NextHopMac->HopCount,
                                NextHopMac->FirstSenderId, NextHopMac->FinalDestination, false, ActivityType::MESSAGE_DROPPED));
                            Message = "";
                        }
                        auto temp = EachClient.incoming_queue.front();
                        EachClient.incoming_queue.pop();
                        while (temp.size() != 0)
                        {
                            auto temp2 = temp.top();
                            temp.pop();
                            delete temp2;
                        }
                        continue;
                    }
                    Message += NextHopMac->CurrentMessage;
                    if (NextHopMac->FrameNumber == 1)
                        cout << "Client " << EachClient.client_id << " receiving a message from client " << FindClientByMac(clients, NextHopMac->sender_MAC_address)->client_id << ", but intended for client " << NextHopMac->FinalDestination << ". Forwarding..." << endl;
                    NextHopMac->sender_MAC_address = EachClient.client_mac;
                    Client* NextCli = FindClientById(clients, EachClient.routing_table[NextHopMac->FinalDestination]);
                    if (!NextCli)
                    {
                        EachClient.incoming_queue.pop();
                        continue;
                    }
                    NextHopMac->receiver_MAC_address = NextCli->client_mac;
                    cout << "Frame #" << NextHopMac->FrameNumber << " MAC address change: New sender MAC " << NextHopMac->sender_MAC_address << ", new receiver MAC " << NextHopMac->receiver_MAC_address << endl;
                    if (NextHopMac->MaxFrameNumber == NextHopMac->FrameNumber)
                        cout << "--------" << endl;
                    if (NextHopMac->FrameNumber == NextHopMac->MaxFrameNumber)
                    {
                        // todo delete previous log

                        auto now = std::chrono::system_clock::now();
                        std::time_t now_c = std::chrono::system_clock::to_time_t(now);
                        std::tm tm_now = *std::localtime(&now_c);
                        std::stringstream ss;
                        ss << std::put_time(&tm_now, "%Y-%m-%d %H:%M:%S");
                        std::string str_time = ss.str();
                        EachClient.log_entries.push_back(Log(str_time, Message, NextHopMac->MaxFrameNumber, NextHopMac->HopCount,
                            NextHopMac->FirstSenderId, NextHopMac->FinalDestination, true, ActivityType::MESSAGE_FORWARDED));
                        Message = "";
                    }
                    if (!EachClient.incoming_queue.empty()) {
                        std::stack<Packet*> RemovedStack = EachClient.incoming_queue.front();
                        EachClient.incoming_queue.pop();

                        EachClient.outgoing_queue.push(RemovedStack);
                    }

                }

            }
        }
        else if (CurrentCommand == "SHOW_FRAME_INFO")
        {
            /*string ShowId;
            string QueueSelection;
            int SelectedFrame;
            ss >> ShowId >> QueueSelection >> SelectedFrame;
            Client* ShowClient = FindClientById(clients, ShowId);
            cout << "--------------------------" << endl << "Command: " << EachCommand << endl << "--------------------------" << endl;
            if (!ShowClient)
            {
                cout << "No such frame." << endl;
                continue;
            }
            queue<stack<Packet*>> SelectedQueue;
            if (QueueSelection == "in")
            {
                SelectedQueue = ShowClient->incoming_queue;
                if (SelectedQueue.size() == 0)
                {
                    cout << "No such frame." << endl;
                    continue;
                }
                cout << "Current Frame #" << SelectedFrame << " on the incoming queue of client " << ShowId << endl;

            }
            else if (QueueSelection == "out")
            {

                SelectedQueue = ShowClient->outgoing_queue;
                if (SelectedQueue.size() == 0)
                {
                    cout << "No such frame." << endl;
                    continue;
                }
                cout << "Current Frame #" << SelectedFrame << " on the outgoing queue of client " << ShowId << endl;
            }

            auto TempQueue = SelectedQueue;
            bool bDidFail = false;
            for (int i = 1; i < SelectedFrame; i++)
            {
                if (TempQueue.size() == 0)
                {
                    bDidFail = true;
                    break;
                }
                TempQueue.pop();
            }
            if (bDidFail || TempQueue.size() == 0)
            {
                cout << "No such frame." << endl;
                continue;
            }
            cout << "Carried Message: " << '"' << TempQueue.front().top()->CurrentMessage << '"' << endl;
            auto TempStack = TempQueue.front();
            if (TempStack.size() != 4) continue;
            PhysicalLayerPacket* TempLayer4 = dynamic_cast<PhysicalLayerPacket*>(TempStack.top());
            TempStack.pop();
            NetworkLayerPacket* TempLayer3 = dynamic_cast<NetworkLayerPacket*>(TempStack.top());
            TempStack.pop();
            TransportLayerPacket* TempLayer2 = dynamic_cast<TransportLayerPacket*>(TempStack.top());
            TempStack.pop();
            ApplicationLayerPacket* TempLayer1 = dynamic_cast<ApplicationLayerPacket*>(TempStack.top());
            TempStack.pop();
            cout << "Layer 0 info: Sender ID: " << TempLayer1->sender_ID << ", Receiver ID: " << TempLayer1->receiver_ID << endl;
            cout << "Layer 1 info: Sender port number: " << TempLayer2->sender_port_number << ", Receiver port number: " << TempLayer2->receiver_port_number << endl;
            cout << "Layer 2 info: Sender IP address: " << TempLayer3->sender_IP_address << ", Receiver IP address: " << TempLayer3->receiver_IP_address << endl;
            cout << "Layer 3 info: Sender MAC address: " << TempLayer4->sender_MAC_address << ", Receiver MAC address: " << TempLayer4->receiver_MAC_address << endl;
            cout << "Number of hops so far: " << TempLayer4->HopCount << endl;*/


        }
        else if (CurrentCommand == "SHOW_Q_INFO")
        {
            string ShowId;
            string QueueSelection;
            ss >> ShowId >> QueueSelection;
            Client* ShowClient = FindClientById(clients, ShowId);
            cout << "--------------------------" << endl << "Command: " << EachCommand << endl << "--------------------------" << endl;
            if (!ShowClient)
            {
                cout << "No such frame." << endl;
                continue;
            }
            if (QueueSelection == "in")
            {
                cout << "Client " << ShowId << " Incoming Queue Status" << endl;
                cout << "Current total number of frames: " << ShowClient->incoming_queue.size() << endl;
            }
            else if (QueueSelection == "out")
            {
                cout << "Client " << ShowId << " Outgoing Queue Status" << endl;
                cout << "Current total number of frames: " << ShowClient->outgoing_queue.size() << endl;
            }

        }
        else if (CurrentCommand == "PRINT_LOG")
        {
            cout << "--------------------\nCommand: " << EachCommand << endl << "--------------------" << endl;

            string Id;
            ss >> Id;
            Client* CurrentClient = FindClientById(clients, Id);
            if (CurrentClient->log_entries.size() != 0) cout << "Client " << Id << " Logs:" << endl << "--------------" << endl;
            int LogEntry = 1;
            for (auto EachLog : CurrentClient->log_entries)
            {
                cout << "Log Entry #" << LogEntry << ":" << endl;
                LogEntry++;
                switch (EachLog.activity_type)
                {
                case (ActivityType::MESSAGE_RECEIVED):
                    cout << "Activity: Message Received" << endl;
                    break;
                case (ActivityType::MESSAGE_DROPPED):
                    cout << "Activity: Message Dropped" << endl;
                    break;
                case (ActivityType::MESSAGE_FORWARDED):
                    cout << "Activity: Message Forwarded" << endl;
                    break;
                case (ActivityType::MESSAGE_SENT):
                    cout << "Activity: Message Sent" << endl;
                    break;
                default:
                    break;
                }
                cout << "Timestamp: " << EachLog.timestamp << endl;
                cout << "Number of frames: " << EachLog.number_of_frames << endl;
                cout << "Number of hops: " << EachLog.number_of_hops << endl;
                cout << "Sender ID: " << EachLog.sender_id << endl;
                cout << "Receiver ID: " << EachLog.receiver_id << endl;
                if (EachLog.success_status)
                {
                    cout << "Success: Yes" << endl;
                    if (EachLog.activity_type != ActivityType::MESSAGE_FORWARDED)
                        cout << "Message: " << '"' << EachLog.message_content << '"' << endl;
                    if (CurrentClient->log_entries.size() != LogEntry) cout << "--------------" << endl;
                }

                else cout << "Success: No" << endl;



            }


        }
        else
        {
            cout << "--------------------\nCommand: " << EachCommand << endl << "--------------------" << endl;
            cout << "Invalid command." << endl;

        }

    }
}

vector<Client> Network::read_clients(const string& filename)
{
    vector<Client> clients;
    ifstream InputFile(filename);
    string CurrentLine;
    while (getline(InputFile, CurrentLine))
    {
        if (CurrentLine.find(" ") >= CurrentLine.size()) continue;
        string Id;
        string Ip;
        string Mac;
        stringstream ss(CurrentLine);
        ss >> Id >> Ip >> Mac;
        clients.push_back(Client(Id, Ip, Mac));
    }

    // TODO: Read clients from the given input file and return a vector of Client instances.
    return clients;
}

void Network::read_routing_tables(vector<Client>& clients, const string& filename)
{
    // TODO: Read the routing tables from the given input file and populate the clients' routing_table member variable.
    ifstream InputFile(filename);
    for (auto& EachClient : clients)
    {
        string CurrentLine;
        while (getline(InputFile, CurrentLine) && CurrentLine != "-")
        {
            stringstream ss(CurrentLine);
            string ReceiverId;
            string NextHopId;
            ss >> ReceiverId >> NextHopId;
            EachClient.routing_table[ReceiverId] = NextHopId;
        }
    }
}

// Returns a list of token lists for each command
vector<string> Network::read_commands(const string& filename)
{
    vector<string> commands;
    // TODO: Read commands from the given input file and return them as a vector of strings.
    ifstream InputFile(filename);
    string CurrentLine;
    int x = 0;
    while (getline(InputFile, CurrentLine))
    {
        if (x == 0)
        {
            x++;
            continue;

        }
        commands.push_back(CurrentLine);
    }
    return commands;
}

Client* Network::FindClientById(vector<Client>& AllClients, string ClientId)
{
    for (auto& EachClient : AllClients)
    {
        if (EachClient.client_id == ClientId)
            return &EachClient;
    }
    return nullptr;
}
Client* Network::FindClientByIpAdress(vector<Client>& AllClients, string ClientIp)
{
    for (auto& EachClient : AllClients)
    {
        if (EachClient.client_ip == ClientIp)
            return &EachClient;
    }
    return nullptr;
}

Client* Network::FindClientByMac(vector<Client>& AllClients, string ClientMac)
{
    for (auto& EachClient : AllClients)
    {
        if (EachClient.client_mac == ClientMac)
            return &EachClient;
    }
    return nullptr;
}

Network::~Network()
{
    // TODO: Free any dynamically allocated memory if necessary.
    for (auto& EachClient : AllClientsVector)
    {
        while (EachClient.incoming_queue.size() != 0)
        {
            auto temp = EachClient.incoming_queue.front();
            EachClient.incoming_queue.pop();
            while (temp.size() != 0)
            {
                auto temp2 = temp.top();
                temp.pop();
                delete temp2;
            }
        }
        while (EachClient.outgoing_queue.size() != 0)
        {
            auto temp = EachClient.outgoing_queue.front();
            EachClient.outgoing_queue.pop();
            while (temp.size() != 0)
            {
                auto temp2 = temp.top();
                temp.pop();
                delete temp2;
            }
        }
    }

}
