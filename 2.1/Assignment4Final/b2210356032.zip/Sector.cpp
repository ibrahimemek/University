#include "Sector.h"

// Constructor implementation

Sector::Sector(int x, int y, int z) : x(x), y(y), z(z), left(nullptr), right(nullptr), parent(nullptr), color(RED) {
    // TODO: Calculate the distance to the Earth, and generate the sector code
}

Sector::~Sector() {
    // TODO: Free any dynamically allocated memory if necessary
}

Sector& Sector::operator=(const Sector& other) {
    // TODO: Overload the assignment operator
    return *this;
}

bool Sector::operator==(const Sector& other) const {
    return (x == other.x && y == other.y && z == other.z);
}

bool Sector::operator!=(const Sector& other) const {
    return !(*this == other);
}

bool Sector::operator>(Sector& other) 
{
    // TODO: Overload the assignment operator
    if (this->x > other.x) return true;
    if (this->x < other.x) return false;
    if (this->y > other.y) return true;
    if (this->y < other.y) return false;
    if (this->z > other.z) return true;
    if (this->z < other.z) return false;
    return false;
}
bool Sector::operator<(Sector& other) {
    // TODO: Overload the assignment operator
    return !((*this) > other);
}