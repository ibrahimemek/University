#ifndef SPACESECTORLLRBT_H
#define SPACESECTORLLRBT_H

#include "Sector.h"
#include <iostream>
#include <fstream>  
#include <sstream>
#include <vector>

class SpaceSectorLLRBT {
public:
    Sector* root;
    SpaceSectorLLRBT();
    ~SpaceSectorLLRBT();
    void readSectorsFromFile(const std::string& filename);
    void insertSectorByCoordinates(int x, int y, int z);
    void insertSectorBySector(Sector* CurrentSector);
    void AddSectorCode(Sector* NewSector);
    void displaySectorsInOrder();
    void displaySectorsPreOrder();
    void displaySectorsPostOrder();
    void PrintInOrder(Sector* PrintAt);
    void PrintPreOrder(Sector* PrintAt);
    void PrintPostOrder(Sector* PrintAt);
    std::vector<Sector*> getStellarPath(const std::string& sector_code);
    void FindPath(const std::string& sector_code, std::vector<Sector*>& CurrentPath);
    void printStellarPath(const std::vector<Sector*>& path);


    Sector* TreeAt;
    void RotateRight(Sector* CurrentSector);
    void RotateLeft(Sector* CurrentSector);
    void printAllPath(int CurrentLine);
    bool bIsReturning = false;
};

#endif // SPACESECTORLLRBT_H
