#include "SpaceSectorBST.h"
#include <cmath>
#include "SpaceSectorLLRBT.h"


using namespace std;




SpaceSectorBST::SpaceSectorBST() : root(nullptr) {}

SpaceSectorBST::~SpaceSectorBST() {
    // Free any dynamically allocated memory in this class.
}

void SpaceSectorBST::readSectorsFromFile(const std::string& filename) 
{
    // TODO: read the sectors from the input file and insert them into the BST sector map
    // according to the given comparison criteria based on the sector coordinates.
    ifstream InputFile(filename);
    string Line;
    bool bIsFirstLine = true;
    while (getline(InputFile, Line))
    {
        if (bIsFirstLine)
        {
            bIsFirstLine = false;
            continue;
        }
        string NumberAsString = "";
        int CharAt = 1;
        int XValue = 0;
        int YValue = 0;
        int ZValue = 0;
        for (auto EachChar : Line)
        {
            if (EachChar == ',')
            {
                if (CharAt == 1)
                {
                    XValue = stoi(NumberAsString);
                    NumberAsString = "";
                    CharAt++;
                }
                else if (CharAt == 2)
                {
                    YValue = stoi(NumberAsString);
                    NumberAsString = "";
                    CharAt++;
                }
                
            }
            else if (EachChar != ' ')
            {
                NumberAsString += EachChar;
            }
        }
        
        ZValue = stoi(NumberAsString);
        NumberAsString = "";
        insertSectorByCoordinates(XValue, YValue, ZValue);
        
    }
}

void SpaceSectorBST::insertSectorByCoordinates(int x, int y, int z) 
{
    // Instantiate and insert a new sector into the space sector BST map according to the 
    // coordinates-based comparison criteria.
    Sector* NewSector = new Sector(x, y, z);
    NewSector->distance_from_earth = sqrt(x * x + y * y + z * z);
    AddSectorCode(NewSector);
    insertSectorBySector(NewSector);

   

}
void SpaceSectorBST::insertSectorBySector(Sector* CurrentSector)
{
    if (!root)
    {
        root = CurrentSector;
        TreeAt = root;
        cout << "root = " << CurrentSector->sector_code << endl;
        return;
    }

    if (*TreeAt > *CurrentSector) // go left
    {
        if (!TreeAt->left)
        {
            TreeAt->left = CurrentSector;
            CurrentSector->parent = TreeAt;
            cout << " Parent " << TreeAt->sector_code << " left one = " << CurrentSector->sector_code  << endl;

            TreeAt = root;
            return;
        }
        TreeAt = TreeAt->left;
    }
    else
    {
        if (!TreeAt->right)
        {
            TreeAt->right = CurrentSector;
            CurrentSector->parent = TreeAt;
            cout << " Parent " << TreeAt->sector_code << " right one = " << CurrentSector->sector_code  << endl;

            TreeAt = root;

            return;
        }
        TreeAt = TreeAt->right;
    }
    insertSectorBySector(CurrentSector);
}

void SpaceSectorBST::AddSectorCode(Sector* NewSector)
{
    NewSector->sector_code += to_string((int)NewSector->distance_from_earth);

    if (NewSector->x > 0) NewSector->sector_code += 'R';
    else if (NewSector->x < 0) NewSector->sector_code += 'L';
    else NewSector->sector_code += 'S';
    if (NewSector->y > 0) NewSector->sector_code += 'U';
    else if (NewSector->y < 0) NewSector->sector_code += 'D';
    else NewSector->sector_code += 'S';
    if (NewSector->z > 0) NewSector->sector_code += 'F';
    else if (NewSector->z < 0) NewSector->sector_code += 'B';
    else NewSector->sector_code += 'S';
}

void SpaceSectorBST::deleteSector(const std::string& sector_code) 
{
    // TODO: Delete the sector given by its sector_code from the BST.
    if (!TreeAt)
    {
        bIsReturning = false;

        return;
    }
    if (TreeAt->sector_code == sector_code)
    {
        if (!TreeAt->left && !TreeAt->right)
        {
            if (TreeAt == root) 
                root = nullptr;
            else if (TreeAt == TreeAt->parent->left)
                TreeAt->parent->left = nullptr;
            else if (TreeAt == TreeAt->parent->right)
                TreeAt->parent->right = nullptr;
            delete TreeAt;
            TreeAt = root;
            return;
        }
        else if (!TreeAt->left || !TreeAt->right)
        {
            if (TreeAt == root)
            {
                if (TreeAt->left)
                {
                    root = TreeAt->left;
                    root->parent = nullptr;
                }
                else
                {
                    root = TreeAt->right;
                    root->parent = nullptr;
                }
                delete TreeAt;
                TreeAt = root;
                return;
            }
            if (TreeAt == TreeAt->parent->left && TreeAt->left)
            {
                TreeAt->parent->left = TreeAt->left;
                TreeAt->left->parent = TreeAt->parent;
            }
            else if (TreeAt == TreeAt->parent->left && TreeAt->right)
            {
                TreeAt->parent->left = TreeAt->right;
                TreeAt->right->parent = TreeAt->parent;

            }
            else if (TreeAt == TreeAt->parent->right && TreeAt->left)
            {
                TreeAt->parent->right = TreeAt->left;
                TreeAt->left->parent = TreeAt->parent;

            }
            else if (TreeAt == TreeAt->parent->right && TreeAt->right)
            {
                TreeAt->parent->right = TreeAt->right;
                TreeAt->right->parent = TreeAt->parent;

            }
            delete TreeAt;
            TreeAt = root;
            return;
        }
        else
        {
            Sector* SuccessorSector = TreeAt->right;
            while (SuccessorSector->left != nullptr)
            {
                SuccessorSector = SuccessorSector->left;
            }
            if (SuccessorSector->right)
            {
                if (SuccessorSector != TreeAt->right)
                {
                    SuccessorSector->right->parent = SuccessorSector->parent;
                    if (SuccessorSector == SuccessorSector->parent->left)
                        SuccessorSector->parent->left = SuccessorSector->right;
                    else
                        SuccessorSector->parent->right = SuccessorSector->right;
                }
                
            }
            else
            {
                if (SuccessorSector != TreeAt->right)
                {
                    SuccessorSector->parent->left = nullptr;
                }

            }

            SuccessorSector->left = TreeAt->left;
            if (SuccessorSector != TreeAt->right) 
                SuccessorSector->right = TreeAt->right;
            SuccessorSector->parent = TreeAt->parent;
            SuccessorSector->left->parent = SuccessorSector;
            if (SuccessorSector != TreeAt->right) 
                SuccessorSector->right->parent = SuccessorSector;
            if (TreeAt == root)
                root = SuccessorSector;
            else if (TreeAt == TreeAt->parent->left)
            {
                TreeAt->parent->left = SuccessorSector;
            }
            else
                TreeAt->parent->right = SuccessorSector;
            if (SuccessorSector != TreeAt->right)
            {
                
                TreeAt->right = nullptr;
            }
            delete TreeAt;
            TreeAt = root;
            return;
        }
    }
    
    

    if (!TreeAt->left && !TreeAt->right) bIsReturning = true;
    if (!bIsReturning && TreeAt->left)
    {
        TreeAt = TreeAt->left;
    }
    else if (!bIsReturning && TreeAt->right)
    {
        TreeAt = TreeAt->right;
    }
    else if (!bIsReturning)
    {
        bIsReturning = true;
    }
    else if (bIsReturning && TreeAt == TreeAt->parent->left)
    {
        if (TreeAt->parent->right)
        {
            TreeAt = TreeAt->parent->right;
            bIsReturning = false;
        }
        else
        {
            TreeAt = TreeAt->parent;
        }
    }
    else if (bIsReturning && TreeAt == TreeAt->parent->right)
    {
        
        TreeAt = TreeAt->parent;
        
    }

    if (TreeAt == root)
    {
        if (TreeAt->sector_code != sector_code)
        {
            bIsReturning = false;

            return;
        }
    }
    deleteSector(sector_code);

    
}

void SpaceSectorBST::displaySectorsInOrder() 
{
    // TODO: Traverse the space sector BST map in-order and print the sectors 
    // to STDOUT in the given format.
    cout << "Space sectors inorder traversal:" << endl;
    PrintInOrder(root);
    cout << endl;
}

void SpaceSectorBST::displaySectorsPreOrder() {
    // TODO: Traverse the space sector BST map in pre-order traversal and print 
    // the sectors to STDOUT in the given format.
    cout << "Space sectors preorder traversal:" << endl;

    PrintPreOrder(root);
    cout << endl;

}

void SpaceSectorBST::displaySectorsPostOrder() 
{
    // TODO: Traverse the space sector BST map in post-order traversal and print 
    // the sectors to STDOUT in the given format.
    cout << "Space sectors postorder traversal:" << endl;

    PrintPostOrder(root);
    cout << endl;


}

void SpaceSectorBST::PrintInOrder(Sector* PrintAt)
{
    // TODO: Traverse the space sector BST map in post-order traversal and print 
    // the sectors to STDOUT in the given format.
    if (!PrintAt) return;
    PrintInOrder(PrintAt->left);
    cout << PrintAt->sector_code << endl;
    PrintInOrder(PrintAt->right);
}
void SpaceSectorBST::PrintPreOrder(Sector* PrintAt)
{
    // TODO: Traverse the space sector BST map in post-order traversal and print 
    // the sectors to STDOUT in the given format.
    if (!PrintAt) return;
    cout << PrintAt->sector_code << endl;
    PrintPreOrder(PrintAt->left);
    PrintPreOrder(PrintAt->right);




}
void SpaceSectorBST::PrintPostOrder(Sector* PrintAt)
{
    // TODO: Traverse the space sector BST map in post-order traversal and print 
    // the sectors to STDOUT in the given format.
    if (!PrintAt) return;
    PrintPostOrder(PrintAt->left);
    PrintPostOrder(PrintAt->right);
    cout << PrintAt->sector_code << endl;
    




}

std::vector<Sector*> SpaceSectorBST::getStellarPath(const std::string& sector_code) 
{
    std::vector<Sector*> path;
    path.push_back(root);
    // TODO: Find the path from the Earth to the destination sector given by its
    // sector_code, and return a vector of pointers to the Sector nodes that are on
    // the path. Make sure that there are no duplicate Sector nodes in the path!
    FindPath(sector_code, path);


    return path;
}

void SpaceSectorBST::FindPath(const std::string& sector_code, std::vector<Sector*>& CurrentPath)
{
    std::vector<Sector*> path;
    // TODO: Find the path from the Earth to the destination sector given by its
    // sector_code, and return a vector of pointers to the Sector nodes that are on
    // the path. Make sure that there are no duplicate Sector nodes in the path!
    
    if (TreeAt->sector_code == sector_code)
    {
        //@todo add deletion
        TreeAt = root;
        bIsReturning = false;
        return;

    }
    if (!TreeAt->left && !TreeAt->right) 
        bIsReturning = true;
    if (!bIsReturning && TreeAt->left)
    {
           TreeAt = TreeAt->left;
        CurrentPath.push_back(TreeAt);
    }
    else if (!bIsReturning && TreeAt->right)
    {
        TreeAt = TreeAt->right;
        CurrentPath.push_back(TreeAt);
    }
    else if (!bIsReturning)
    {
        bIsReturning = true;
    }
    else if (bIsReturning && TreeAt == TreeAt->parent->left)
    {
        if (TreeAt->parent->right)
        {
            CurrentPath.pop_back();
            TreeAt = TreeAt->parent->right;
            CurrentPath.push_back(TreeAt);
            bIsReturning = false;
        }
        else
        {
            CurrentPath.pop_back();
            TreeAt = TreeAt->parent;
        }
    }
    else if (bIsReturning && TreeAt == TreeAt->parent->right)
    {
        
        CurrentPath.pop_back();
        TreeAt = TreeAt->parent;
        
    }
    if (TreeAt == root)
    {
        while (CurrentPath.size() != 0)
        {
            CurrentPath.pop_back();
            
        }
        bIsReturning = false;

        return;
    }
    FindPath(sector_code, CurrentPath);
}

void SpaceSectorBST::printStellarPath(const std::vector<Sector*>& path) {
    // TODO: Print the stellar path obtained from the getStellarPath() function 
    // to STDOUT in the given format.
    if (path.size() == 0)
    {
        cout << "A path to Dr. Elara could not be found." << endl << endl;
        return;
    }
    cout << "The stellar path to Dr. Elara: ";
    for (auto x : path)
    {
        if (x == path.back())
        {
            cout << x->sector_code;
            continue;
        }

        cout << x->sector_code << "->";
    }
    cout << endl;
}

void SpaceSectorBST::printAllPath()
{
    if (!TreeAt->left && !TreeAt->right) bIsReturning = true;
    if (!bIsReturning && TreeAt->left)
    {
        TreeAt = TreeAt->left;
    }
    else if (!bIsReturning && TreeAt->right)
    {
        TreeAt = TreeAt->right;
    }
    else if (!bIsReturning)
    {
        bIsReturning = true;
    }
    else if (bIsReturning && TreeAt == TreeAt->parent->left)
    {
        if (TreeAt->parent->right)
        {
            TreeAt = TreeAt->parent->right;
            bIsReturning = false;
        }
        else
        {
            TreeAt = TreeAt->parent;
        }
    }
    else if (bIsReturning && TreeAt == TreeAt->parent->right)
    {

        TreeAt = TreeAt->parent;

    }

    if (TreeAt == root)
    {
        
        bIsReturning = false;

        return;
        
    }
    if (TreeAt) cout << "Self: " << TreeAt->sector_code << endl;
    if (TreeAt->parent) cout << "Parent: " << TreeAt->parent->sector_code << endl;
    if (TreeAt->left) cout << "Left: " << TreeAt->left->sector_code << endl;
    if (TreeAt->right) cout << "Right: " << TreeAt->right->sector_code << endl;

    printAllPath();
}