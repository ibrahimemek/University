#include "SpaceSectorLLRBT.h"
#include <cmath>


using namespace std;

SpaceSectorLLRBT::SpaceSectorLLRBT() : root(nullptr) {}

void SpaceSectorLLRBT::readSectorsFromFile(const std::string& filename) 
{
    // TODO: read the sectors from the input file and insert them into the LLRBT sector map
    // according to the given comparison criteria based on the sector coordinates.
    ifstream InputFile(filename);
    string Line;
    bool bIsFirstLine = true;
    while (getline(InputFile, Line))
    {
        if (bIsFirstLine)
        {
            bIsFirstLine = false;
            continue;
        }
        string NumberAsString = "";
        int CharAt = 1;
        int XValue = 0;
        int YValue = 0;
        int ZValue = 0;
        for (auto EachChar : Line)
        {
            if (EachChar == ',')
            {
                if (CharAt == 1)
                {
                    XValue = stoi(NumberAsString);
                    NumberAsString = "";
                    CharAt++;
                }
                else if (CharAt == 2)
                {
                    YValue = stoi(NumberAsString);
                    NumberAsString = "";
                    CharAt++;
                }

            }
            else if (EachChar != ' ')
            {
                NumberAsString += EachChar;
            }
        }

        ZValue = stoi(NumberAsString);
        NumberAsString = "";
        insertSectorByCoordinates(XValue, YValue, ZValue);

    }
}
void SpaceSectorLLRBT::insertSectorByCoordinates(int x, int y, int z)
{
    // TODO: Instantiate and insert a new sector into the space sector LLRBT map 
    // according to the coordinates-based comparison criteria.
    Sector* NewSector = new Sector(x, y, z);
    NewSector->distance_from_earth = sqrt(x * x + y * y + z * z);
    AddSectorCode(NewSector);
    insertSectorBySector(NewSector);
    TreeAt = root;



}
void SpaceSectorLLRBT::insertSectorBySector(Sector* CurrentSector)
{
    if (!root)
    {
        root = CurrentSector;
        CurrentSector->color = false;
        TreeAt = root;
        return;
    }

    if (*TreeAt > *CurrentSector) // go left
    {
        if (!TreeAt->left)
        {
            TreeAt->left = CurrentSector;
            CurrentSector->parent = TreeAt;
            CurrentSector->color = true;
            // check for 2 red and right rotation
            if (TreeAt->parent && TreeAt->color)
            {
                RotateRight(TreeAt->parent);
            }
            TreeAt = root;
            return;
        }
        TreeAt = TreeAt->left;
    }
    else
    {
        if (!TreeAt->right)
        {
            TreeAt->right = CurrentSector;
            CurrentSector->parent = TreeAt;
            CurrentSector->color = true;
            // check for right red and left rotation
            RotateLeft(TreeAt);
            
            TreeAt = root;
            return;
        }
        TreeAt = TreeAt->right;
    }
    insertSectorBySector(CurrentSector);
}

void SpaceSectorLLRBT::AddSectorCode(Sector* NewSector)
{
    NewSector->sector_code += to_string((int)NewSector->distance_from_earth);

    if (NewSector->x > 0) NewSector->sector_code += 'R';
    else if (NewSector->x < 0) NewSector->sector_code += 'L';
    else NewSector->sector_code += 'S';
    if (NewSector->y > 0) NewSector->sector_code += 'U';
    else if (NewSector->y < 0) NewSector->sector_code += 'D';
    else NewSector->sector_code += 'S';
    if (NewSector->z > 0) NewSector->sector_code += 'F';
    else if (NewSector->z < 0) NewSector->sector_code += 'B';
    else NewSector->sector_code += 'S';
}

// Remember to handle memory deallocation properly in the destructor.
SpaceSectorLLRBT::~SpaceSectorLLRBT() {
    // TODO: Free any dynamically allocated memory in this class.
}


void SpaceSectorLLRBT::displaySectorsInOrder() 
{
    // TODO: Traverse the space sector LLRBT map in-order and print the sectors 
    // to STDOUT in the given format.
    cout << "Space sectors inorder traversal:" << endl;
    PrintInOrder(root);
    cout << endl;
}

void SpaceSectorLLRBT::displaySectorsPreOrder() 
{
    // TODO: Traverse the space sector LLRBT map in pre-order traversal and print 
    // the sectors to STDOUT in the given format.
    cout << "Space sectors preorder traversal:" << endl;

    PrintPreOrder(root);
    cout << endl;
}

void SpaceSectorLLRBT::displaySectorsPostOrder() 
{
    // TODO: Traverse the space sector LLRBT map in post-order traversal and print 
    // the sectors to STDOUT in the given format.

    cout << "Space sectors postorder traversal:" << endl;

    PrintPostOrder(root);
    cout << endl;
}
void SpaceSectorLLRBT::PrintInOrder(Sector* PrintAt)
{
    // TODO: Traverse the space sector BST map in post-order traversal and print 
    // the sectors to STDOUT in the given format.
    if (!PrintAt) return;
    PrintInOrder(PrintAt->left);
    if (PrintAt->color)
        cout << "RED sector: ";
    else
        cout << "BLACK sector: ";
    cout << PrintAt->sector_code << endl;
    PrintInOrder(PrintAt->right);
}
void SpaceSectorLLRBT::PrintPreOrder(Sector* PrintAt)
{
    // TODO: Traverse the space sector BST map in post-order traversal and print 
    // the sectors to STDOUT in the given format.
    if (!PrintAt) return;
    if (PrintAt->color)
        cout << "RED sector: ";
    else
        cout << "BLACK sector: ";
    cout << PrintAt->sector_code << endl;
    PrintPreOrder(PrintAt->left);
    PrintPreOrder(PrintAt->right);




}
void SpaceSectorLLRBT::PrintPostOrder(Sector* PrintAt)
{
    // TODO: Traverse the space sector BST map in post-order traversal and print 
    // the sectors to STDOUT in the given format.
    if (!PrintAt) return;
    PrintPostOrder(PrintAt->left);
    PrintPostOrder(PrintAt->right);
    if (PrintAt->color)
        cout << "RED sector: ";
    else
        cout << "BLACK sector: ";
    cout << PrintAt->sector_code << endl;





}

std::vector<Sector*> SpaceSectorLLRBT::getStellarPath(const std::string& sector_code) 
{
    std::vector<Sector*> path;
    // TODO: Find the path from the Earth to the destination sector given by its
    // sector_code, and return a vector of pointers to the Sector nodes that are on
    // the path. Make sure that there are no duplicate Sector nodes in the path!
    path.push_back(root);
    FindPath(sector_code, path);
    return path;
}

void SpaceSectorLLRBT::FindPath(const std::string& sector_code, std::vector<Sector*>& CurrentPath)
{
    std::vector<Sector*> path;
    // TODO: Find the path from the Earth to the destination sector given by its
    // sector_code, and return a vector of pointers to the Sector nodes that are on
    // the path. Make sure that there are no duplicate Sector nodes in the path!

    if (TreeAt->sector_code == sector_code)
    {
        TreeAt = root;
        bIsReturning = false;
        return;

    }
    if (!TreeAt->left && !TreeAt->right)
        bIsReturning = true;
    if (!bIsReturning && TreeAt->left)
    {
        TreeAt = TreeAt->left;
        CurrentPath.push_back(TreeAt);
    }
    else if (!bIsReturning && TreeAt->right)
    {
        TreeAt = TreeAt->right;
        CurrentPath.push_back(TreeAt);
    }
    else if (!bIsReturning)
    {
        bIsReturning = true;
    }
    else if (bIsReturning && TreeAt == TreeAt->parent->left)
    {
        if (TreeAt->parent->right)
        {
            CurrentPath.pop_back();
            TreeAt = TreeAt->parent->right;
            CurrentPath.push_back(TreeAt);
            bIsReturning = false;
        }
        else
        {
            CurrentPath.pop_back();
            TreeAt = TreeAt->parent;
        }
    }
    else if (bIsReturning && TreeAt == TreeAt->parent->right)
    {

        CurrentPath.pop_back();
        TreeAt = TreeAt->parent;

    }
    if (TreeAt == root)
    {
        while (CurrentPath.size() != 0)
        {
            CurrentPath.pop_back();

        }
        bIsReturning = false;

        return;
    }
    FindPath(sector_code, CurrentPath);
}

void SpaceSectorLLRBT::printStellarPath(const std::vector<Sector*>& path) 
{
    // TODO: Print the stellar path obtained from the getStellarPath() function 
    // to STDOUT in the given format.
    if (path.size() == 0)
    {
        cout << "A path to Dr. Elara could not be found." << endl << endl;
        return;
    }
    cout << "The stellar path to Dr. Elara: ";
    for (auto x : path)
    {
        if (x == path.back())
        {
            cout << x->sector_code;
            continue;
        }

        cout << x->sector_code << "->";
    }
    cout << endl;
}

void SpaceSectorLLRBT::RotateRight(Sector* CurrentSector)
{
    Sector* Child = CurrentSector->left;
    if (CurrentSector->parent)
    {
        Child->parent = CurrentSector->parent;
        if (CurrentSector == CurrentSector->parent->left)
            CurrentSector->parent->left = Child;
        else
            CurrentSector->parent->right = Child;
    }
    else
    {
        root = Child;
        Child->parent = nullptr;
    }
    
    CurrentSector->left = Child->right;
    if (CurrentSector->left) CurrentSector->left->parent = CurrentSector;
    Child->right = CurrentSector;
    CurrentSector->parent = Child;
    Child->color = true;
    CurrentSector->color = false;
    Child->right->color = false;
    root->color = false;

    /*Sector* Child = CurrentSector->left;
    if (CurrentSector == root) root = Child;
    CurrentSector->left = Child->right;
    Child->right = CurrentSector;
    Child->color = CurrentSector->color;
    
    if (CurrentSector->parent && CurrentSector == CurrentSector->parent->left)
        CurrentSector->parent->left = Child;
    else if (CurrentSector->parent && CurrentSector == CurrentSector->parent->right)
        CurrentSector->parent->right = Child;
    if (CurrentSector->left) 
        CurrentSector->left->parent = CurrentSector;
    Child->parent = CurrentSector->parent;
    CurrentSector->parent = Child;
    
    if (Child->left && Child->right && Child->left->color && Child->right->color)
    {
        if (Child != root) Child->color = true;
        Child->left->color = false;
        Child->right->color = false;
    }
    cout << "after rotate right " << endl << endl;
    printAllPath(1);*/


}

void SpaceSectorLLRBT::RotateLeft(Sector* CurrentSector)
{
    Sector* Child = CurrentSector->right;
    if (CurrentSector->parent)
    {
        Child->parent = CurrentSector->parent;
        if (CurrentSector == CurrentSector->parent->left)
            CurrentSector->parent->left = Child;
        else
            CurrentSector->parent->right = Child;
    }
    else
    {
        root = Child;
        Child->parent = nullptr;
    }
    CurrentSector->right = Child->left;
    if (CurrentSector->right)  CurrentSector->right->parent = CurrentSector;
    Child->left = CurrentSector;
    Child->color = CurrentSector->color;
    CurrentSector->color = true;

    
    Child->parent = CurrentSector->parent;
    CurrentSector->parent = Child;
    root->color = false;

    if (CurrentSector->color && CurrentSector->left && CurrentSector->left->color) RotateRight(CurrentSector->parent);
    else if (Child->left && Child->right && Child->left->color && Child->right->color)
    {
        Child->color = true;
        Child->left->color = false;
        Child->right->color = false;
    }
    




}

void SpaceSectorLLRBT::printAllPath(int CurrentLine)
{
    if (!TreeAt->left && !TreeAt->right) bIsReturning = true;
    if (!bIsReturning && TreeAt->left)
    {
        TreeAt = TreeAt->left;
        CurrentLine++;
    }
    else if (!bIsReturning && TreeAt->right)
    {
        TreeAt = TreeAt->right;
        CurrentLine++;
    }
    else if (!bIsReturning)
    {
        bIsReturning = true;
    }
    else if (bIsReturning && TreeAt == TreeAt->parent->left)
    {
        if (TreeAt->parent->right)
        {
            TreeAt = TreeAt->parent->right;
            bIsReturning = false;
        }
        else
        {
            TreeAt = TreeAt->parent;
            CurrentLine--;
        }
    }
    else if (bIsReturning && TreeAt == TreeAt->parent->right)
    {

        TreeAt = TreeAt->parent;
        CurrentLine--;
    }

    if (TreeAt == root)
    {

        bIsReturning = false;

        return;

    }
    if (TreeAt) cout << "Self: " << TreeAt->sector_code << endl;
    if (TreeAt) cout << "Color: " << TreeAt->color << endl;
    if (TreeAt->parent) cout << "Parent: " << TreeAt->parent->sector_code << endl;
    if (TreeAt->left) cout << "Left: " << TreeAt->left->sector_code << endl;
    if (TreeAt->right) cout << "Right: " << TreeAt->right->sector_code << endl;
    cout << "Current Line: " << CurrentLine << endl << endl;

    printAllPath(CurrentLine);
}

