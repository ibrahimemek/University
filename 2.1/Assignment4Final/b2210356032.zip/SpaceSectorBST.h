#ifndef SPACESECTORBST_H
#define SPACESECTORBST_H

#include <iostream>
#include <fstream>  
#include <sstream>
#include <vector>

#include "Sector.h"

class SpaceSectorBST {

public:
    Sector* root = nullptr;
    SpaceSectorBST();
    ~SpaceSectorBST();
    void readSectorsFromFile(const std::string& filename);
    void insertSectorByCoordinates(int x, int y, int z);
    
    void AddSectorCode(Sector* NewSector);
    void deleteSector(const std::string& sector_code);
    void displaySectorsInOrder();
    void displaySectorsPreOrder();
    void displaySectorsPostOrder();
    std::vector<Sector*> getStellarPath(const std::string& sector_code);
    void printStellarPath(const std::vector<Sector*>& path);

    void printAllPath();

    Sector* TreeAt;
    bool bIsReturning = false;
    
    void insertSectorBySector(Sector* CurrentSector);
    void PrintInOrder(Sector* PrintAt);

    void PrintPreOrder(Sector* PrintAt);

    void PrintPostOrder(Sector* PrintAt);

    void FindPath(const std::string& sector_code, std::vector<Sector*>& CurrentPath);

};

#endif // SPACESECTORBST_H
